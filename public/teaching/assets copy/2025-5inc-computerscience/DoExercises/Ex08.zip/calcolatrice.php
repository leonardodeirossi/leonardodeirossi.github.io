<?php

/**
 * Esercizio: la calcolatrice.
 * Completare le porzioni di codice mancante per implementare le quattro operazioni fondamentali.
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero1 = $_POST["numero1"];
    $numero2 = $_POST["numero2"];

    $operazione = $_POST["operazione"];

    /* Definire qui la variabile $risultato */

    /* ----- */

    switch ($operazione) {
        /* Inserire qui i vari casi */

        /* ----- */

        default:
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Calcolatrice</title>

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        button {
            font-weight: bold;
            cursor: pointer;
        }

        .success {
            font-weight: bold;
            color: green;
        }
    </style>
</head>

<body>
    <h1>Calcolatrice</h1>
    <hr>

    <form id="form" method="POST" action="calcolatrice.php">
        <label for="numero1">Numero 1:</label>
        <input type="number" id="numero1" name="numero1">

        &nbsp;

        <label for="numero2">Numero 2:</label>
        <input type="number" id="numero2" name="numero2">

        <br><br>

        <label for="operazione">Operazione:</label>
        <select id="operazione" name="operazione">
            <option value="">- seleziona -</option>
            <option value="+">(+) Addizione</option>
            <option value="-">(-) Sottrazione</option>
            <option value="*">(*) Moltiplicazione</option>
            <option value="/">(/) Divisione</option>
        </select>

        <br><br><br>

        <button type="button" onclick="invia()">CALCOLA</button>
    </form>

    <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
        <p class="success">
            Il risultato dell'operazione &egrave;: <?php echo ($risultato); ?>
        </p>
    <?php } ?>

    <script>
        function invia() {
            if (document.getElementById("numero1").value == "") {
                alert("Inserire numero 1");
                return;
            }

            if (document.getElementById("numero2").value == "") {
                alert("Inserire numero 2");
                return;
            }

            if (document.getElementById("operazione").value == "") {
                alert("Selezionare l'operazione");
                return;
            }

            document.getElementById("form").submit();
        }
    </script>
</body>

</html>