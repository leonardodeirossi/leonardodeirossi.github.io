let libri = [
    {
        id: 1,
        titolo: "Trilogia del Nerva",
        autore: "Charlotte J. Bright",
        anno_uscita: 2024,
        numero_pagine: 878,
        is_letto: true
    },
    {
        id: 2,
        titolo: "Game of Gods - Discesa agli Inferi",
        autore: "Hazel Riley",
        anno_uscita: 2023,
        numero_pagine: 694,
        is_letto: true
    },
    {
        id: 3,
        titolo: "Game of Titans - Ascesa al Paradiso",
        autore: "Hazel Riley",
        anno_uscita: 2024,
        numero_pagine: 831,
        is_letto: true
    },
    {
        id: 4,
        titolo: "La custode di mia sorella",
        autore: "Jodi Picoult",
        anno_uscita: 2004,
        numero_pagine: 428,
        is_letto: true
    },
    {
        id: 5,
        titolo: "Limitless. Senza morale",
        autore: "Karim B.",
        anno_uscita: 2024,
        numero_pagine: 932,
        is_letto: false
    },
    {
        id: 6,
        titolo: "Dall'amore all'amore: il diritto di famiglia",
        autore: "Annamaria Bernardini de Pace",
        anno_uscita: 2012,
        numero_pagine: 288,
        is_letto: false
    },
    {
        id: 7,
        titolo: "Il Nerva: le origini",
        autore: "Charlotte J. Bright",
        anno_uscita: 2025,
        numero_pagine: 453,
        is_letto: false
    },
    {
        id: 8,
        titolo: "Balleremo la musica che suonano",
        autore: "Fabio Volo",
        anno_uscita: 2024,
        numero_pagine: 192,
        is_letto: true
    },
    {
        id: 9,
        titolo: "Game of Desire - Devozione",
        autore: "Hazel Riley",
        anno_uscita: 2025,
        numero_pagine: 494,
        is_letto: true
    },
    {
        id: 10,
        titolo: "Game of Chaos - Redenzione",
        autore: "Hazel Riley",
        anno_uscita: 2024,
        numero_pagine: 987,
        is_letto: true
    },
    {
        id: 11,
        titolo: "Steve Jobs",
        autore: "Walter Isaacson",
        anno_uscita: 2011,
        numero_pagine: 630,
        is_letto: true
    },
    {
        id: 12,
        titolo: "Ho imparato a ridere",
        autore: "Richard Romagnoli",
        anno_uscita: 2013,
        numero_pagine: 300,
        is_letto: true
    }
];